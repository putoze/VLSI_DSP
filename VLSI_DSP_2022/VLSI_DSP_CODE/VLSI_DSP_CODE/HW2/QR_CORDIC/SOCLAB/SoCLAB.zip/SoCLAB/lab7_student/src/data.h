#include <stdint.h>
#include <stddef.h>


#define PATTERN_SIZE 20

typedef uint8_t u8;
typedef uint64_t u64;
typedef uint32_t u32;


u32 SD_Transfer_Data [PATTERN_SIZE];
u32 SD_Receive_Data  [PATTERN_SIZE];
u32 DMA_Transfer_gold [PATTERN_SIZE/2];




